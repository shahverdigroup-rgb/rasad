package com.rasad.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final int BG_DARK = 0xFF080D18;   // matches --bg in dark theme
    private static final int BG_LIGHT = 0xFFF2F2F7;  // matches --bg in light theme

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;

        webView = new WebView(this);
        applyBars(night);               // no white flash before the page paints
        setContentView(webView);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // The page loads only its own bundled file and calls public APIs,
        // so the file:// origin must be allowed to fetch them (no CORS blocking).
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        // Minimal native bridge: haptics, reduced-motion flag, system-bar colours. Nothing else.
        webView.addJavascriptInterface(new Bridge(), "RasadNative");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) { }
                return true;
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    /** Status/navigation bar + window + WebView background follow the app theme. */
    private void applyBars(boolean dark) {
        int bg = dark ? BG_DARK : BG_LIGHT;
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setBackgroundDrawable(new ColorDrawable(bg));
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        View d = w.getDecorView();
        int flags = d.getSystemUiVisibility();
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) light |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        d.setSystemUiVisibility(dark ? (flags & ~light) : (flags | light));
        if (webView != null) webView.setBackgroundColor(bg);
    }

    private int hapticFor(String kind) {
        final int sdk = Build.VERSION.SDK_INT;
        switch (kind) {
            case "tick":  return sdk >= 27 ? HapticFeedbackConstants.TEXT_HANDLE_MOVE : HapticFeedbackConstants.CLOCK_TICK;
            case "light": return HapticFeedbackConstants.CLOCK_TICK;
            case "start": return sdk >= 30 ? HapticFeedbackConstants.GESTURE_START : HapticFeedbackConstants.CONTEXT_CLICK;
            case "drop":  return sdk >= 30 ? HapticFeedbackConstants.GESTURE_END : HapticFeedbackConstants.CONTEXT_CLICK;
            case "long":  return HapticFeedbackConstants.LONG_PRESS;
            case "del":   return sdk >= 30 ? HapticFeedbackConstants.REJECT : HapticFeedbackConstants.LONG_PRESS;
            default:      return -1;
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void haptic(String kind) {
            final int c = hapticFor(kind == null ? "" : kind);
            if (c < 0) return;
            // performHapticFeedback honours the user's system "touch feedback" setting.
            runOnUiThread(() -> { if (webView != null) webView.performHapticFeedback(c); });
        }

        /** True when the system animation scale is 0 ("Remove animations"). */
        @JavascriptInterface
        public boolean rm() {
            try {
                return Settings.Global.getFloat(getContentResolver(),
                        Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void setBars(final boolean dark) {
            runOnUiThread(() -> applyBars(dark));
        }
    }

    /** Back closes edit mode / detail / picker first (handled in the page), then exits. */
    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{return window.rasadBack?window.rasadBack():false}catch(e){return false}})()",
                value -> { if (!"true".equals(value)) finish(); });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("RasadNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
